#!/usr/bin/env python3
"""Local web interface for Rocket Test Video Overlay."""

from __future__ import annotations

import json
import os
import threading
import uuid
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.utils import secure_filename

from rocket_overlay import (
    Config, RocketOverlayError, default_scene_config, render, resolve_column,
    validate_scene_config,
)


BASE_DIR = Path(__file__).resolve().parent
WORK_DIR = BASE_DIR / "workspace"
UPLOAD_DIR = WORK_DIR / "uploads"
OUTPUT_DIR = WORK_DIR / "outputs"
VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v"}
DATA_EXTENSIONS = {".xlsx", ".xls", ".xlsm", ".csv", ".txt"}
LOGO_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}

for directory in (UPLOAD_DIR, OUTPUT_DIR):
    directory.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024 * 1024
jobs: dict[str, dict[str, Any]] = {}
jobs_lock = threading.Lock()
chunk_uploads: dict[str, dict[str, Any]] = {}
chunk_uploads_lock = threading.Lock()


def error(message: str, status: int = 400):
    return jsonify({"error": message}), status


def save_upload(field: str, job_dir: Path, extensions: set[str], required: bool = True) -> Path | None:
    uploaded = request.files.get(field)
    if not uploaded or not uploaded.filename:
        if required:
            raise RocketOverlayError(f"الملف المطلوب غير موجود: {field}")
        return None
    suffix = Path(uploaded.filename).suffix.lower()
    if suffix not in extensions:
        raise RocketOverlayError(f"صيغة الملف غير مدعومة: {uploaded.filename}")
    name = secure_filename(uploaded.filename) or f"{field}{suffix}"
    path = job_dir / name
    uploaded.save(path)
    return path


def consume_upload(
    field: str,
    job_dir: Path,
    extensions: set[str],
    required: bool = True,
) -> Path | None:
    token = request.form.get(f"{field}_token", "").strip()
    if not token:
        return save_upload(field, job_dir, extensions, required)
    with chunk_uploads_lock:
        item = chunk_uploads.pop(token, None)
    if not item or item["field"] != field:
        raise RocketOverlayError(f"رمز رفع الملف غير صالح: {field}")
    source = Path(item["path"])
    if not source.exists() or source.stat().st_size != item["received"]:
        raise RocketOverlayError(f"لم يكتمل رفع الملف: {field}")
    destination = job_dir / item["filename"]
    source.replace(destination)
    source.parent.rmdir()
    return destination


def read_columns(path: Path, sheet: str | int = 0) -> list[str]:
    try:
        if path.suffix.lower() in {".xlsx", ".xls", ".xlsm"}:
            frame = pd.read_excel(path, sheet_name=sheet, nrows=12)
        else:
            frame = pd.read_csv(path, nrows=12)
    except Exception as exc:
        raise RocketOverlayError(f"تعذر قراءة ملف القياسات: {exc}") from exc
    if frame.empty and not len(frame.columns):
        raise RocketOverlayError("ملف القياسات لا يحتوي على أعمدة.")
    return [str(column) for column in frame.columns]


def form_float(name: str, default: float) -> float:
    value = request.form.get(name, "").strip()
    try:
        return default if value == "" else float(value)
    except ValueError as exc:
        raise RocketOverlayError(f"القيمة غير صحيحة للحقل: {name}") from exc


def form_int(name: str, default: int) -> int:
    value = request.form.get(name, "").strip()
    try:
        return default if value == "" else int(value)
    except ValueError as exc:
        raise RocketOverlayError(f"القيمة غير صحيحة للحقل: {name}") from exc


def run_job(job_id: str, cfg: Config) -> None:
    def progress(percent: int, message: str) -> None:
        with jobs_lock:
            jobs[job_id].update(progress=percent, message=message)

    try:
        render(cfg, progress)
        thumbnail = cfg.output.with_name(cfg.output.stem + "_thumbnail.jpg")
        summary = cfg.output.with_suffix(".json")
        with jobs_lock:
            jobs[job_id].update(
                status="complete",
                progress=100,
                message="اكتمل إنشاء الفيديو",
                result_url=f"/outputs/{job_id}/{cfg.output.name}",
                thumbnail_url=f"/outputs/{job_id}/{thumbnail.name}" if thumbnail.exists() else None,
                summary_url=f"/outputs/{job_id}/{summary.name}" if summary.exists() else None,
            )
    except Exception as exc:
        with jobs_lock:
            jobs[job_id].update(
                status="error",
                message=str(exc),
            )


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/uploads/init")
def initialize_upload():
    payload = request.get_json(silent=True) or {}
    field = str(payload.get("field", ""))
    filename = secure_filename(str(payload.get("filename", "")))
    expected_size = int(payload.get("size", 0) or 0)
    allowed = {
        "video": VIDEO_EXTENSIONS, "video_2": VIDEO_EXTENSIONS,
        "video_3": VIDEO_EXTENSIONS, "data": DATA_EXTENSIONS,
        "logo": LOGO_EXTENSIONS,
    }
    if field not in allowed or not filename:
        return error("بيانات الملف غير صحيحة.")
    if Path(filename).suffix.lower() not in allowed[field]:
        return error(f"صيغة الملف غير مدعومة: {filename}")
    upload_id = uuid.uuid4().hex
    upload_dir = UPLOAD_DIR / f"chunk-{upload_id}"
    upload_dir.mkdir(parents=True)
    path = upload_dir / filename
    reused = False
    if expected_size > 0:
        candidates = sorted(
            (
                candidate for candidate in UPLOAD_DIR.glob(f"*/{filename}")
                if not candidate.parent.name.startswith("chunk-")
                and candidate.is_file()
                and candidate.stat().st_size == expected_size
            ),
            key=lambda candidate: candidate.stat().st_mtime,
            reverse=True,
        )
        if candidates:
            path.hardlink_to(candidates[0])
            reused = True
    if not reused:
        path.touch()
    with chunk_uploads_lock:
        chunk_uploads[upload_id] = {
            "field": field, "filename": filename, "path": str(path),
            "received": expected_size if reused else 0,
            "reused": reused,
        }
    return jsonify({"upload_id": upload_id, "reused": reused})


@app.post("/api/uploads/<upload_id>")
def append_upload(upload_id: str):
    chunk = request.get_data(cache=False)
    if not chunk:
        return error("جزء الملف فارغ.")
    with chunk_uploads_lock:
        item = chunk_uploads.get(upload_id)
        if not item:
            return error("جلسة رفع الملف غير موجودة.", 404)
        if item.get("reused"):
            return jsonify({"upload_id": upload_id, "received": item["received"]})
        path = Path(item["path"])
        with path.open("ab") as stream:
            stream.write(chunk)
        item["received"] += len(chunk)
        received = item["received"]
    return jsonify({"upload_id": upload_id, "received": received})


@app.post("/api/inspect")
def inspect_data():
    temp_dir = UPLOAD_DIR / f"inspect-{uuid.uuid4().hex}"
    temp_dir.mkdir(parents=True)
    try:
        path = save_upload("data", temp_dir, DATA_EXTENSIONS)
        sheet_value = request.form.get("sheet", "0").strip()
        sheet: str | int = int(sheet_value) if sheet_value.isdigit() else sheet_value
        columns = read_columns(path, sheet)
        frame = (
            pd.read_excel(path, sheet_name=sheet)
            if path.suffix.lower() in {".xlsx", ".xls", ".xlsm"}
            else pd.read_csv(path)
        )
        preview = frame.head(5)
        detected = {}
        for kind in ("time", "pressure", "thrust"):
            try:
                detected[kind] = resolve_column(preview, None, kind)
            except RocketOverlayError:
                detected[kind] = ""
        sample = frame
        if len(sample) > 700:
            # Keep the preview lightweight without truncating the test trace.
            # Evenly distributed indices preserve ignition, tail-off, and the
            # final timestamp instead of returning only the first 700 rows.
            indices = np.linspace(0, len(sample) - 1, num=700, dtype=int)
            sample = sample.iloc[np.unique(indices)]
        return jsonify({
            "columns": columns,
            "detected": detected,
            "rows": preview.fillna("").astype(str).to_dict(orient="records"),
            "series": sample.fillna("").astype(str).to_dict(orient="records"),
            "default_scene": default_scene_config(),
        })
    except RocketOverlayError as exc:
        return error(str(exc))
    finally:
        for child in temp_dir.glob("*"):
            child.unlink(missing_ok=True)
        temp_dir.rmdir()


@app.post("/api/jobs")
def create_job():
    job_id = uuid.uuid4().hex
    job_dir = UPLOAD_DIR / job_id
    job_dir.mkdir(parents=True)
    try:
        video = consume_upload("video", job_dir, VIDEO_EXTENSIONS)
        video_2 = consume_upload("video_2", job_dir, VIDEO_EXTENSIONS, required=False)
        video_3 = consume_upload("video_3", job_dir, VIDEO_EXTENSIONS, required=False)
        data = consume_upload("data", job_dir, DATA_EXTENSIONS)
        logo = consume_upload("logo", job_dir, LOGO_EXTENSIONS, required=False)
        resolution = request.form.get("resolution", "1920x1080").split("x")
        if len(resolution) != 2:
            raise RocketOverlayError("دقة الإخراج غير صحيحة.")

        sheet_value = request.form.get("sheet", "0").strip()
        sheet: str | int = int(sheet_value) if sheet_value.lstrip("-").isdigit() else sheet_value
        telemetry_zero = request.form.get("telemetry_zero_s", "").strip()
        output_style = request.form.get("output_style", "engineering")
        style_video_fraction = {
            "engineering": 0.70,
            "presentation": 0.76,
            "archive": 0.66,
            "social": 0.62,
        }.get(output_style, 0.70)
        raw_scene = request.form.get("scene_config", "").strip()
        scene_config = validate_scene_config(json.loads(raw_scene)) if raw_scene else None
        cfg = Config(
            video=video,
            video_2=video_2,
            video_3=video_3,
            camera_2_ignition_s=form_float("camera_2_ignition_s", 0.0),
            camera_3_ignition_s=form_float("camera_3_ignition_s", 0.0),
            camera_mode=request.form.get("camera_mode", "single"),
            camera_3_switch_delay_s=form_float("camera_3_switch_delay_s", 2.0),
            camera_2_crop_zoom=form_float("camera_2_crop_zoom", 1.0),
            camera_2_crop_x=form_float("camera_2_crop_x", 0.5),
            camera_2_crop_y=form_float("camera_2_crop_y", 0.5),
            camera_3_crop_zoom=form_float("camera_3_crop_zoom", 1.0),
            camera_3_crop_x=form_float("camera_3_crop_x", 0.5),
            camera_3_crop_y=form_float("camera_3_crop_y", 0.5),
            data=data,
            output=OUTPUT_DIR / job_id / "rocket_test_overlay.mp4",
            sheet=sheet,
            time_column=request.form.get("time_column") or None,
            pressure_column=request.form.get("pressure_column") or None,
            thrust_column=request.form.get("thrust_column") or None,
            ignition_video_s=form_float("ignition_video_s", 0.0),
            telemetry_zero_s=float(telemetry_zero) if telemetry_zero else None,
            time_scale=form_float("time_scale", 1.0),
            title=request.form.get("title", "").strip() or "ROCKET MOTOR STATIC TEST",
            subtitle=request.form.get("subtitle", "").strip() or "Pressure & Derived Thrust",
            pressure_unit=request.form.get("pressure_unit", "").strip() or "bar",
            thrust_unit=request.form.get("thrust_unit", "").strip() or "N",
            width=int(resolution[0]),
            height=int(resolution[1]),
            video_fraction=form_float("video_fraction", style_video_fraction),
            logo=logo,
            test_date=request.form.get("test_date", "").strip(),
            motor_type=request.form.get("motor_type", "").strip(),
            propellant=request.form.get("propellant", "").strip(),
            run_number=request.form.get("run_number", "").strip(),
            output_style=output_style,
            intro_duration_s=form_float("intro_duration_s", 0.0),
            outro_duration_s=form_float("outro_duration_s", 2.5),
            reveal_chart=request.form.get("reveal_chart") == "true",
            enhance_video=request.form.get("enhance_video") == "true",
            denoise_video=request.form.get("denoise_video") == "true",
            stabilize_video=request.form.get("stabilize_video") == "true",
            crop_zoom=form_float("crop_zoom", 1.0),
            crop_x=form_float("crop_x", 0.5),
            crop_y=form_float("crop_y", 0.5),
            pressure_limit=(
                form_float("pressure_limit", 0.0)
                if request.form.get("pressure_limit", "").strip() else None
            ),
            thumbnail=request.form.get("thumbnail") == "true",
            delivery_codec=request.form.get("delivery_codec", "h264"),
            keep_audio=request.form.get("keep_audio") == "true",
            scene_config=scene_config,
        )
        cfg.output.parent.mkdir(parents=True, exist_ok=True)
        with jobs_lock:
            jobs[job_id] = {
                "id": job_id,
                "status": "queued",
                "progress": 0,
                "message": "بانتظار بدء المعالجة",
            }
        thread = threading.Thread(target=run_job, args=(job_id, cfg), daemon=True)
        thread.start()
        return jsonify(jobs[job_id]), 202
    except (RocketOverlayError, ValueError, json.JSONDecodeError) as exc:
        return error(str(exc))


@app.get("/api/default-scene")
def default_scene():
    return jsonify(default_scene_config())


@app.get("/api/jobs/<job_id>")
def job_status(job_id: str):
    with jobs_lock:
        job = jobs.get(job_id)
        return jsonify(job) if job else error("المهمة غير موجودة.", 404)


@app.get("/outputs/<job_id>/<path:filename>")
def output_file(job_id: str, filename: str):
    return send_from_directory(OUTPUT_DIR / job_id, filename, conditional=True)


if __name__ == "__main__":
    app.run(
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "5000")),
        debug=False,
    )
