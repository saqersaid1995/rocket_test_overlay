const form = document.querySelector("#renderForm");
const videoInput = document.querySelector("#videoInput");
const videoInput2 = document.querySelector("#videoInput2");
const videoInput3 = document.querySelector("#videoInput3");
const dataInput = document.querySelector("#dataInput");
const logoInput = document.querySelector("#logoInput");
const video = document.querySelector("#previewVideo");
const video2 = document.querySelector("#previewVideo2");
const video3 = document.querySelector("#previewVideo3");
const stage = document.querySelector("#editorStage");
const elementHost = document.querySelector("#sceneElements");
const chartSvg = document.querySelector("#chartPreview");
const toast = document.querySelector("#toast");

const names = {
  video: "الفيديو", chart: "المخطط", title: "العنوان", timecode: "الوقت والمزامنة",
  pressure_card: "بطاقة الضغط", thrust_card: "بطاقة الدفع", status: "حالة الاختبار",
  identity: "بيانات الاختبار", logo: "الشعار"
};
let scene = null;
let initialScene = null;
let selectedId = null;
let previewUrl = null;
let previewUrl2 = null;
let previewUrl3 = null;
let logoUrl = null;
let telemetryRows = [];
let pollTimer = null;
let undoStack = [];
let redoStack = [];
let dragState = null;
let propertyEditing = false;
let cameraPanState = null;

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function clamp(value, low, high) { return Math.max(low, Math.min(high, value)); }
function selected() { return scene?.elements.find(item => item.id === selectedId); }
function notify(message) {
  toast.textContent = message; toast.style.display = "block";
  window.setTimeout(() => toast.style.display = "none", 4200);
}
function fileName(input, id) {
  document.querySelector(id).textContent = input.files[0]?.name || "لم يتم اختيار ملف";
}
function snapshot() {
  if (!scene || propertyEditing) return;
  undoStack.push(JSON.stringify(scene));
  if (undoStack.length > 60) undoStack.shift();
  redoStack = [];
}
function restore(serialized) {
  scene = JSON.parse(serialized); selectedId = null; renderScene(); selectElement(null);
}
function applyEngineeringTheme(target) {
  target.designRevision = 3;
  target.background = "#0A0F14";
  const styles = {
    title:{color:"#E6EDF3",background:"#0A1118",backgroundOpacity:.78},
    timecode:{color:"#AAB7C4",background:"#0A1118",backgroundOpacity:.68},
    chart:{background:"#07121C",backgroundOpacity:.96,pressureColor:"#35C2FF",thrustColor:"#FFB454",gridColor:"#668096",cursorColor:"#F8FAFC",fillOpacity:.16,lineWidth:4,borderRadius:8,chartType:"area"},
    pressure_card:{color:"#79A9C6",background:"#101820",backgroundOpacity:.94},
    thrust_card:{color:"#C99B63",background:"#101820",backgroundOpacity:.94},
    status:{color:"#8FB89D",background:"#101820",backgroundOpacity:.94},
    identity:{color:"#AAB7C4"}
  };
  target.elements.forEach(element=>Object.assign(element,styles[element.type]||{}));
  return target;
}

async function initialize() {
  const saved = localStorage.getItem("rocket-overlay-scene");
  try {
    const response = await fetch("/api/default-scene");
    initialScene = await response.json();
    scene = saved ? JSON.parse(saved) : clone(initialScene);
    if ((scene.designRevision || 0) < 3) {
      applyEngineeringTheme(scene);
      saveDraft();
    }
  } catch {
    notify("تعذر تحميل التصميم الافتراضي.");
    return;
  }
  renderScene();
  bindProperties();
}

videoInput.addEventListener("change", () => {
  fileName(videoInput, "#videoName");
  if (!videoInput.files[0]) return;
  if (previewUrl) URL.revokeObjectURL(previewUrl);
  previewUrl = URL.createObjectURL(videoInput.files[0]);
  video.src = previewUrl; video.style.display = "block";
  document.querySelector("#emptyPreview").classList.add("hidden");
});
videoInput2.addEventListener("change", () => fileName(videoInput2, "#videoName2"));
videoInput3.addEventListener("change", () => fileName(videoInput3, "#videoName3"));
function setCameraSource(input, target, urlKey) {
  const oldUrl = urlKey === 2 ? previewUrl2 : previewUrl3;
  if (oldUrl) URL.revokeObjectURL(oldUrl);
  const nextUrl = input.files[0] ? URL.createObjectURL(input.files[0]) : null;
  if (urlKey === 2) previewUrl2 = nextUrl; else previewUrl3 = nextUrl;
  if (nextUrl) target.src = nextUrl; else target.removeAttribute("src");
  updateCameraPreview();
}
videoInput2.addEventListener("change", () => setCameraSource(videoInput2, video2, 2));
videoInput3.addEventListener("change", () => setCameraSource(videoInput3, video3, 3));
document.querySelector("#cameraMode").addEventListener("change", updateCameraPreview);
document.querySelector("#cameraPreviewMode").addEventListener("change", updateCameraPreview);

function cameraSourceTime(cameraNumber) {
  const primaryIgnition = Number(form.elements.ignition_video_s.value || 0);
  const cameraIgnition = Number(form.elements[`camera_${cameraNumber}_ignition_s`].value || 0);
  return video.currentTime - primaryIgnition + cameraIgnition;
}
function syncSecondaryCameras() {
  [[video2,2],[video3,3]].forEach(([camera,number]) => {
    if (!camera.src) return;
    const target = cameraSourceTime(number);
    if (target >= 0 && Number.isFinite(camera.duration) && Math.abs(camera.currentTime-target) > .2)
      camera.currentTime = Math.min(target, camera.duration);
  });
}
function updateCameraPreview() {
  const cameras = [video, video2, video3];
  cameras.forEach(camera => {
    camera.style.cssText = "display:none;position:absolute;object-fit:cover;";
  });
  if (!video.src) return;
  const previewChoice = document.querySelector("#cameraPreviewMode").value;
  if (previewChoice !== "layout") {
    const chosen = cameras[Number(previewChoice) - 1];
    if (!chosen?.src) {
      notify(`اختر ملف الكاميرا ${previewChoice} أولًا.`);
      document.querySelector("#cameraPreviewMode").value = "layout";
    } else {
      chosen.style.cssText = "display:block;position:absolute;object-fit:cover;inset:0;width:100%;height:100%;";
      applyCameraFocus(chosen, Number(previewChoice));
      syncSecondaryCameras();
      return;
    }
  }
  const mode = form.elements.camera_mode.value;
  const active = cameras.filter(camera => camera.src);
  if (mode === "split" && active.length > 1) {
    active.forEach((camera,index) => {
      camera.style.cssText = `display:block;position:absolute;object-fit:cover;height:100%;width:${100/active.length}%;left:${index*100/active.length}%;top:0;`;
      applyCameraFocus(camera, cameras.indexOf(camera) + 1);
    });
  } else if (mode === "pip" && active.length > 1) {
    video.style.cssText = "display:block;position:absolute;object-fit:cover;inset:0;width:100%;height:100%;";
    applyCameraFocus(video, 1);
    active.slice(1).forEach((camera,index) => {
      camera.style.cssText = `display:block;position:absolute;object-fit:cover;width:30%;height:30%;right:2%;top:${2+index*32}%;z-index:8;border:2px solid #eef6fb;`;
      applyCameraFocus(camera, cameras.indexOf(camera) + 1);
    });
  } else if (mode === "switch" && active.length > 1) {
    const ignition = Number(form.elements.ignition_video_s.value || 0);
    const delay = Number(form.elements.camera_3_switch_delay_s.value || 2);
    const chosen = active.length > 2 && video.currentTime >= ignition + delay
      ? video3 : (video.currentTime >= ignition ? video2 : video);
    const visible = chosen.src ? chosen : video;
    visible.style.cssText = "display:block;position:absolute;object-fit:cover;inset:0;width:100%;height:100%;";
    applyCameraFocus(visible, cameras.indexOf(visible) + 1);
  } else {
    video.style.cssText = "display:block;position:absolute;object-fit:cover;inset:0;width:100%;height:100%;";
    applyCameraFocus(video, 1);
  }
  syncSecondaryCameras();
}
function applyCameraFocus(camera, number) {
  const prefix = number === 1 ? "" : `camera_${number}_`;
  const x = Number(form.elements[`${prefix}crop_x`]?.value ?? .5);
  const y = Number(form.elements[`${prefix}crop_y`]?.value ?? .5);
  camera.style.objectPosition = `${x * 100}% ${y * 100}%`;
}
function cameraAtPointer(event) {
  const explicit = document.querySelector("#cameraPreviewMode").value;
  if (explicit !== "layout") return Number(explicit);
  const mode = form.elements.camera_mode.value;
  const available = [video, video2, video3].filter(camera => camera.src);
  if (mode === "split" && available.length > 1) {
    const rect = stage.getBoundingClientRect();
    const cell = Math.min(
      available.length - 1,
      Math.max(0, Math.floor((event.clientX - rect.left) / rect.width * available.length))
    );
    return [video, video2, video3].indexOf(available[cell]) + 1;
  }
  return explicit === "layout" ? 1 : Number(explicit);
}
stage.addEventListener("pointerdown", event => {
  if (!document.querySelector("#cameraDragMode").checked) return;
  const cameraNumber = cameraAtPointer(event);
  const prefix = cameraNumber === 1 ? "" : `camera_${cameraNumber}_`;
  cameraPanState = {
    pointerId:event.pointerId, cameraNumber,
    startX:event.clientX, startY:event.clientY,
    cropX:Number(form.elements[`${prefix}crop_x`].value),
    cropY:Number(form.elements[`${prefix}crop_y`].value)
  };
  stage.setPointerCapture(event.pointerId);
  event.preventDefault(); event.stopPropagation();
}, true);
stage.addEventListener("pointermove", event => {
  if (!cameraPanState || event.pointerId !== cameraPanState.pointerId) return;
  const rect = stage.getBoundingClientRect();
  const prefix = cameraPanState.cameraNumber === 1 ? "" : `camera_${cameraPanState.cameraNumber}_`;
  form.elements[`${prefix}crop_x`].value = clamp(
    cameraPanState.cropX - (event.clientX-cameraPanState.startX)/rect.width, 0, 1
  );
  form.elements[`${prefix}crop_y`].value = clamp(
    cameraPanState.cropY - (event.clientY-cameraPanState.startY)/rect.height, 0, 1
  );
  updateCameraPreview();
  event.preventDefault(); event.stopPropagation();
}, true);
stage.addEventListener("pointerup", event => {
  if (!cameraPanState || event.pointerId !== cameraPanState.pointerId) return;
  cameraPanState = null;
  stage.releasePointerCapture(event.pointerId);
  event.preventDefault(); event.stopPropagation();
}, true);
video.addEventListener("loadedmetadata", () => {
  document.querySelector("#duration").textContent = formatTime(video.duration);
  updateIgnitionMarker(); updateCameraPreview(); renderPreview();
});
video.addEventListener("timeupdate", () => {
  if (!video.duration) return;
  document.querySelector("#timelineRange").value = video.currentTime / video.duration * 1000;
  updateCameraPreview(); renderPreview();
});
video.addEventListener("play", () => {
  document.querySelector("#playButton").textContent = "❚❚";
  syncSecondaryCameras();
  [video2, video3].forEach(camera => camera.src && camera.play().catch(()=>{}));
});
video.addEventListener("pause", () => {
  document.querySelector("#playButton").textContent = "▶";
  [video2, video3].forEach(camera => camera.pause());
});

logoInput.addEventListener("change", () => {
  fileName(logoInput, "#logoName");
  if (logoUrl) URL.revokeObjectURL(logoUrl);
  logoUrl = logoInput.files[0] ? URL.createObjectURL(logoInput.files[0]) : null;
  renderScene();
});
dataInput.addEventListener("change", inspectData);
["timeColumn", "pressureColumn", "thrustColumn"].forEach(id =>
  document.querySelector(`#${id}`).addEventListener("change", renderPreview)
);
form.elements.telemetry_zero_s.addEventListener("input", renderPreview);
form.elements.time_scale.addEventListener("change", renderPreview);
form.elements.ignition_video_s.addEventListener("input", () => { updateIgnitionMarker(); renderPreview(); });
["camera_2_ignition_s","camera_3_ignition_s","camera_3_switch_delay_s"].forEach(name =>
  form.elements[name].addEventListener("input", updateCameraPreview)
);
[
  "crop_x","crop_y","crop_zoom",
  "camera_2_crop_x","camera_2_crop_y","camera_2_crop_zoom",
  "camera_3_crop_x","camera_3_crop_y","camera_3_crop_zoom"
].forEach(name => form.elements[name].addEventListener("input", updateCameraPreview));
form.elements.title.addEventListener("input", renderPreview);
["run_number", "motor_type", "propellant", "test_date"].forEach(name =>
  form.elements[name].addEventListener("input", renderPreview)
);

async function inspectData() {
  fileName(dataInput, "#dataName");
  if (!dataInput.files[0]) return;
  const body = new FormData();
  body.append("data", dataInput.files[0]);
  body.append("sheet", form.elements.sheet.value);
  try {
    const response = await fetch("/api/inspect", { method: "POST", body });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error);
    telemetryRows = payload.series || [];
    for (const kind of ["time", "pressure", "thrust"]) {
      const select = document.querySelector(`#${kind}Column`);
      const optional = kind === "thrust" ? '<option value="__none__">غير متوفر — ضغط فقط</option>' : "";
      select.innerHTML = optional + payload.columns.map(column =>
        `<option value="${escapeHtml(column)}">${escapeHtml(column)}</option>`).join("");
      select.value = payload.detected[kind] || (kind === "thrust" ? "__none__" : payload.columns[0]);
    }
    renderPreview();
    notify("تم تحليل القياسات وتجهيز المعاينة الحية.");
  } catch (error) { notify(error.message); }
}
function escapeHtml(value) {
  const div = document.createElement("div"); div.textContent = value; return div.innerHTML;
}

function renderScene() {
  if (!scene) return;
  elementHost.innerHTML = "";
  const elements = [...scene.elements].sort((a, b) => (a.z || 0) - (b.z || 0));
  for (const element of elements) {
    if (element.type === "video") continue;
    if (element.type === "chart") {
      positionNode(chartSvg, element);
      chartSvg.style.opacity = element.visible === false ? "0" : String(element.opacity ?? 1);
    }
    const node = document.createElement("div");
    node.className = `scene-element ${element.type} ${["pressure_card","thrust_card"].includes(element.type) ? "card" : ""}`;
    node.dataset.id = element.id;
    positionNode(node, element);
    node.style.zIndex = String((element.z || 0) + 40);
    node.style.opacity = element.visible === false ? ".12" : String(element.opacity ?? 1);
    node.style.background = hexAlpha(element.background || "#0F172A", element.backgroundOpacity || 0);
    node.style.color = element.color || "#fff";
    node.style.setProperty("--font-scale", String(element.fontSize || 1));
    if (element.id === selectedId) node.classList.add("selected");
    if (element.locked) node.classList.add("locked");
    node.innerHTML = `<div class="content">${elementContent(element)}</div><i class="resize-handle"></i>`;
    node.addEventListener("pointerdown", beginDrag);
    node.querySelector(".resize-handle").addEventListener("pointerdown", beginResize);
    elementHost.appendChild(node);
  }
  stage.style.background = scene.background || "#0B1017";
  renderLayers(); renderPreview();
}
function positionNode(node, element) {
  node.style.left = `${element.x * 100}%`; node.style.top = `${element.y * 100}%`;
  node.style.width = `${element.width * 100}%`; node.style.height = `${element.height * 100}%`;
  if (element.type === "chart") node.style.borderRadius = `${element.borderRadius || 0}px`;
}
function elementContent(element) {
  if (element.type === "title") return escapeHtml(form.elements.title.value);
  if (element.type === "timecode") return `<span id="liveTimecode">VIDEO 00.00s | TELEMETRY +00.00s</span>`;
  if (element.type === "identity") return escapeHtml(identityText());
  if (element.type === "pressure_card") return `<b>PRESSURE</b><strong id="livePressure">0.00 ${escapeHtml(form.elements.pressure_unit.value)}</strong>`;
  if (element.type === "thrust_card") return `<b>THRUST</b><strong id="liveThrust">0.0 ${escapeHtml(form.elements.thrust_unit.value)}</strong>`;
  if (element.type === "status") return `<span id="liveStatus">STANDBY</span>`;
  if (element.type === "logo") return logoUrl ? `<img src="${logoUrl}" alt="" style="width:100%;height:100%;object-fit:contain">` : "LOGO";
  return "";
}
function identityText() {
  return ["run_number","motor_type","propellant","test_date"].map(name => form.elements[name].value).filter(Boolean).join(" • ");
}
function hexAlpha(hex, alpha) {
  const value = String(hex || "#000000").replace("#", "");
  const r = parseInt(value.slice(0,2),16)||0, g=parseInt(value.slice(2,4),16)||0, b=parseInt(value.slice(4,6),16)||0;
  return `rgba(${r},${g},${b},${alpha})`;
}

function renderLayers() {
  const list = document.querySelector("#layersList"); list.innerHTML = "";
  [...scene.elements].sort((a,b)=>(b.z||0)-(a.z||0)).forEach(element => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `layer ${element.id === selectedId ? "active" : ""} ${element.visible === false ? "muted" : ""}`;
    button.innerHTML = `<span class="drag">⠿</span><span>${names[element.type]}</span><span class="lock">${element.locked ? "🔒" : element.visible === false ? "◌" : "◉"}</span>`;
    button.addEventListener("click", () => selectElement(element.id));
    list.appendChild(button);
  });
}
function selectElement(id) {
  selectedId = id;
  document.querySelectorAll(".scene-element").forEach(node => node.classList.toggle("selected", node.dataset.id === id));
  renderLayers();
  const element = selected();
  document.querySelector("#noSelection").classList.toggle("hidden", !!element);
  document.querySelector("#propertyEditor").classList.toggle("hidden", !element);
  document.querySelector("#selectedName").textContent = element ? names[element.type] : "اختر عنصرًا";
  if (!element) return;
  setPropertyValues(element);
}

function beginDrag(event) {
  const id = event.currentTarget.dataset.id;
  selectElement(id);
  const element = selected();
  if (element.locked || event.target.classList.contains("resize-handle")) return;
  snapshot();
  dragState = { mode:"move", startX:event.clientX, startY:event.clientY, x:element.x, y:element.y };
  event.currentTarget.setPointerCapture(event.pointerId);
}
function beginResize(event) {
  event.stopPropagation();
  const node = event.currentTarget.parentElement;
  selectElement(node.dataset.id);
  const element = selected();
  if (element.locked) return;
  snapshot();
  dragState = { mode:"resize", startX:event.clientX, startY:event.clientY, w:element.width, h:element.height };
  node.setPointerCapture(event.pointerId);
}
window.addEventListener("pointermove", event => {
  if (!dragState || !selected()) return;
  const rect = stage.getBoundingClientRect();
  const dx = (event.clientX - dragState.startX) / rect.width;
  const dy = (event.clientY - dragState.startY) / rect.height;
  const element = selected();
  if (dragState.mode === "move") {
    element.x = snap(clamp(dragState.x + dx, 0, 1 - element.width));
    element.y = snap(clamp(dragState.y + dy, 0, 1 - element.height));
  } else {
    element.width = snap(clamp(dragState.w + dx, .03, 1 - element.x));
    element.height = snap(clamp(dragState.h + dy, .03, 1 - element.y));
  }
  renderScene(); selectElement(element.id);
});
window.addEventListener("pointerup", () => { if (dragState) saveDraft(); dragState = null; });
function snap(value) {
  const points = [0,.05,.1,.25,.5,.75,.9,.95,1];
  const near = points.find(point => Math.abs(point - value) < .008);
  return near ?? Math.round(value * 1000) / 1000;
}

function bindProperties() {
  const geometry = { propX:"x", propY:"y", propW:"width", propH:"height" };
  Object.entries(geometry).forEach(([id,key]) => {
    const input = document.querySelector(`#${id}`);
    input.addEventListener("focus", beginPropertyEdit);
    input.addEventListener("input", () => {
      const element = selected(); if (!element) return;
      element[key] = Number(input.value) / 100;
      element[key] = clamp(element[key], key === "width" || key === "height" ? .01 : 0, 1);
      renderScene(); selectElement(element.id);
    });
    input.addEventListener("change", endPropertyEdit);
  });
  bindRange("propOpacity", "opacity", 100, "opacityValue");
  bindRange("propBackgroundOpacity", "backgroundOpacity", 100, "backgroundOpacityValue");
  bindRange("lineWidth", "lineWidth", 1, "lineWidthValue");
  bindRange("fillOpacity", "fillOpacity", 100, "fillOpacityValue");
  bindRange("borderRadius", "borderRadius", 1, null);
  bindRange("fontSize", "fontSize", 100, "fontSizeValue");
  bindColor("propColor", "color"); bindColor("propBackground", "background");
  bindColor("pressureColor", "pressureColor"); bindColor("thrustColor", "thrustColor");
  bindColor("gridColor", "gridColor"); bindColor("cursorColor", "cursorColor");
  ["showGrid","showAxes","showTitle"].forEach(key => {
    document.querySelector(`#${key}`).addEventListener("change", event => {
      snapshot(); selected()[key] = event.target.checked; renderScene(); selectElement(selectedId); saveDraft();
    });
  });
  document.querySelector("#chartType").addEventListener("change", event => {
    mutateSelected(element => element.chartType = event.target.value);
  });
  for (const key of ["startTime","endTime","fadeIn","fadeOut"]) {
    const input=document.querySelector(`#${key}`);
    input.addEventListener("focus",beginPropertyEdit);
    input.addEventListener("change",()=>{
      const element=selected(); if(!element)return;
      element[key]=input.value===""?null:Number(input.value);
      endPropertyEdit();
    });
  }
}
function beginPropertyEdit() { if (!propertyEditing) snapshot(); propertyEditing = true; }
function endPropertyEdit() { propertyEditing = false; saveDraft(); }
function bindRange(id, key, divisor, outputId) {
  const input = document.querySelector(`#${id}`);
  input.addEventListener("pointerdown", beginPropertyEdit);
  input.addEventListener("input", () => {
    const element = selected(); if (!element) return;
    element[key] = Number(input.value) / divisor;
    if (outputId) document.querySelector(`#${outputId}`).textContent =
      divisor === 100 ? `${input.value}%` : input.value;
    renderScene(); selectElement(element.id);
  });
  input.addEventListener("change", endPropertyEdit);
}
function bindColor(id, key) {
  document.querySelector(`#${id}`).addEventListener("input", event => {
    if (!propertyEditing) beginPropertyEdit();
    selected()[key] = event.target.value; renderScene(); selectElement(selectedId);
  });
  document.querySelector(`#${id}`).addEventListener("change", endPropertyEdit);
}
function setPropertyValues(element) {
  document.querySelector("#propX").value = (element.x * 100).toFixed(1);
  document.querySelector("#propY").value = (element.y * 100).toFixed(1);
  document.querySelector("#propW").value = (element.width * 100).toFixed(1);
  document.querySelector("#propH").value = (element.height * 100).toFixed(1);
  document.querySelector("#propOpacity").value = (element.opacity ?? 1) * 100;
  document.querySelector("#opacityValue").textContent = `${Math.round((element.opacity ?? 1)*100)}%`;
  document.querySelector("#propColor").value = element.color || "#ffffff";
  document.querySelector("#propBackground").value = element.background || "#0f172a";
  document.querySelector("#propBackgroundOpacity").value = (element.backgroundOpacity ?? 0) * 100;
  document.querySelector("#backgroundOpacityValue").textContent = `${Math.round((element.backgroundOpacity ?? 0)*100)}%`;
  document.querySelector("#toggleVisible").textContent = element.visible === false ? "إظهار" : "إخفاء";
  document.querySelector("#toggleLock").textContent = element.locked ? "فتح القفل" : "قفل";
  const chart = element.type === "chart";
  document.querySelector("#textProperties").classList.toggle("hidden", chart || element.type === "video" || element.type === "logo");
  document.querySelector("#fontSize").value = (element.fontSize ?? 1) * 100;
  document.querySelector("#fontSizeValue").textContent = `${Math.round((element.fontSize ?? 1)*100)}%`;
  for (const key of ["startTime","endTime","fadeIn","fadeOut"])
    document.querySelector(`#${key}`).value = element[key] ?? "";
  document.querySelector("#chartProperties").classList.toggle("hidden", !chart);
  if (chart) {
    document.querySelector("#chartType").value = element.chartType || "line";
    for (const key of ["pressureColor","thrustColor","gridColor","cursorColor"])
      document.querySelector(`#${key}`).value = element[key];
    document.querySelector("#lineWidth").value = element.lineWidth || 3;
    document.querySelector("#lineWidthValue").textContent = element.lineWidth || 3;
    document.querySelector("#fillOpacity").value = (element.fillOpacity ?? .2)*100;
    document.querySelector("#fillOpacityValue").textContent = `${Math.round((element.fillOpacity ?? .2)*100)}%`;
    document.querySelector("#borderRadius").value = element.borderRadius || 0;
    for (const key of ["showGrid","showAxes","showTitle"]) document.querySelector(`#${key}`).checked = element[key] !== false;
  }
}

function renderPreview() {
  if (!scene) return;
  const chart = scene.elements.find(item => item.type === "chart");
  if (!chart) return;
  positionNode(chartSvg, chart);
  const time = video.currentTime || 0;
  const ignition = Number(form.elements.ignition_video_s.value) || 0;
  const telemetryTime = time - ignition;
  const series = normalizedSeries();
  const current = interpolate(series, telemetryTime);
  drawChart(series, telemetryTime, chart);
  const timecode = document.querySelector("#liveTimecode");
  if (timecode) timecode.textContent = `VIDEO ${time.toFixed(2)}s | TELEMETRY ${telemetryTime >= 0 ? "+" : ""}${telemetryTime.toFixed(2)}s`;
  const pressure = document.querySelector("#livePressure");
  if (pressure) pressure.textContent = `${current.pressure.toFixed(2)} ${form.elements.pressure_unit.value}`;
  const thrust = document.querySelector("#liveThrust");
  if (thrust) thrust.textContent = `${current.thrust.toFixed(1)} ${form.elements.thrust_unit.value}`;
  const status = document.querySelector("#liveStatus");
  if (status) status.textContent = telemetryTime < -.12 ? "STANDBY" : telemetryTime < .18 ? "IGNITION" : "TEST ACTIVE";
  document.querySelector("#currentTime").textContent = formatTime(time);
}
function normalizedSeries() {
  const tKey=form.elements.time_column.value,pKey=form.elements.pressure_column.value,fKey=form.elements.thrust_column.value;
  const scale=Number(form.elements.time_scale.value)||1;
  const raw = telemetryRows.map(row=>({time:Number(row[tKey]),pressure:Number(row[pKey]),thrust:fKey==="__none__"?0:Number(row[fKey])})).filter(row=>Number.isFinite(row.time)&&Number.isFinite(row.pressure));
  const zeroText=form.elements.telemetry_zero_s.value;
  const zero=zeroText!==""?Number(zeroText):(raw[0]?.time||0);
  return raw.map(row=>({...row,time:(row.time-zero)*scale}));
}
function interpolate(series,time) {
  if (!series.length || time<series[0].time || time>series.at(-1).time) return {pressure:0,thrust:0};
  let right=series.findIndex(item=>item.time>=time); if(right<=0)return series[0];
  const a=series[right-1],b=series[right],ratio=(time-a.time)/(b.time-a.time||1);
  return {pressure:a.pressure+(b.pressure-a.pressure)*ratio,thrust:a.thrust+(b.thrust-a.thrust)*ratio};
}
function drawChart(series,time,style) {
  chartSvg.setAttribute("viewBox","0 0 1000 600");
  if (!series.length) { chartSvg.innerHTML=""; return; }
  const visible=document.querySelector("#revealChart").checked?series.filter(item=>item.time<=time):series;
  const maxP=Math.max(1,...series.map(item=>item.pressure)),maxF=Math.max(1,...series.map(item=>item.thrust));
  const minT=series[0].time,maxT=series.at(-1).time,px=t=>115+(t-minT)/(maxT-minT||1)*805,py=p=>500-p/maxP*365,fy=f=>500-f/maxF*365;
  const pathFor=(items,yValue)=>{
    if(style.chartType==="step")return items.map((item,index)=>{
      const x=px(item.time).toFixed(1),y=yValue(item).toFixed(1);
      return index?`H${x} V${y}`:`M${x},${y}`;
    }).join(" ");
    return items.map((item,index)=>`${index?"L":"M"}${px(item.time).toFixed(1)},${yValue(item).toFixed(1)}`).join(" ");
  };
  const pPath=pathFor(visible,item=>py(item.pressure));
  const fPath=pathFor(visible,item=>fy(item.thrust));
  const cursor=clamp(px(time),115,920);
  const live=interpolate(series,time);
  let grid="";
  let ticks="";
  const pUnit=escapeHtml(form.elements.pressure_unit.value),fUnit=escapeHtml(form.elements.thrust_unit.value);
  for(let i=0;i<=5;i++){
    const y=500-i*73,pValue=maxP*i/5;
    if(style.showGrid!==false)grid+=`<line x1="115" y1="${y}" x2="920" y2="${y}" stroke="${style.gridColor}" opacity=".34"/>`;
    if(style.showAxes!==false)ticks+=`<text x="98" y="${y+7}" text-anchor="end" fill="#E2EAF0" font-size="21" font-weight="600">${pValue.toFixed(maxP<10?1:0)}</text>`;
  }
  for(let i=0;i<=4;i++){
    const value=minT+(maxT-minT)*i/4,x=px(value);
    if(style.showGrid!==false)grid+=`<line x1="${x}" y1="135" x2="${x}" y2="500" stroke="${style.gridColor}" opacity=".20"/>`;
    if(style.showAxes!==false)ticks+=`<text x="${x}" y="536" text-anchor="middle" fill="#D5E0E8" font-size="20" font-weight="600">${value.toFixed(1)}</text>`;
  }
  const title=style.showTitle!==false?`<text x="42" y="45" fill="#F5F9FC" font-size="29" font-weight="700">${escapeHtml(form.elements.subtitle.value)}</text><text x="42" y="78" fill="#AFC0CC" font-size="18" font-weight="600">PEAK  ${maxP.toFixed(2)} ${pUnit}</text><line x1="42" y1="98" x2="958" y2="98" stroke="#668096" opacity=".65"/>`:"";
  const legend=`<circle cx="690" cy="48" r="7" fill="${style.pressureColor}"/><text x="706" y="55" fill="#DDE7EE" font-size="19" font-weight="600">PRESSURE</text>${maxF>1?`<circle cx="850" cy="48" r="7" fill="${style.thrustColor}"/><text x="866" y="55" fill="#DDE7EE" font-size="19" font-weight="600">THRUST</text>`:""}`;
  const axes=style.showAxes!==false?`<line x1="115" y1="135" x2="115" y2="500" stroke="#7890A2" stroke-width="2"/><line x1="115" y1="500" x2="920" y2="500" stroke="#7890A2" stroke-width="2"/><text x="518" y="580" text-anchor="middle" fill="#C8D5DE" font-size="20" font-weight="700">TIME FROM IGNITION  (s)</text><text x="28" y="318" text-anchor="middle" fill="${style.pressureColor}" font-size="20" font-weight="700" transform="rotate(-90 28 318)">PRESSURE  (${pUnit})</text>`:"";
  const fill=pPath&&visible.length&&style.chartType==="area"?`<path d="${pPath} L${px(visible.at(-1).time)},500 L${px(visible[0].time)},500 Z" fill="${style.pressureColor}" opacity="${style.fillOpacity||0}"/>`:"";
  const traces=style.chartType==="points"
    ? visible.map(item=>`<circle cx="${px(item.time)}" cy="${py(item.pressure)}" r="${(style.lineWidth||3)+1}" fill="${style.pressureColor}"/><circle cx="${px(item.time)}" cy="${fy(item.thrust)}" r="${(style.lineWidth||3)+1}" fill="${style.thrustColor}"/>`).join("")
    : `<path d="${pPath}" fill="none" stroke="${style.pressureColor}" stroke-width="${style.lineWidth||3}" stroke-linejoin="round" stroke-linecap="round"/><path d="${fPath}" fill="none" stroke="${style.thrustColor}" stroke-width="${style.lineWidth||3}" stroke-linejoin="round"/>`;
  const livePoint=visible.length?`<circle cx="${cursor}" cy="${py(live.pressure)}" r="10" fill="#07121C" stroke="#F8FAFC" stroke-width="3"/><circle cx="${cursor}" cy="${py(live.pressure)}" r="5" fill="${style.pressureColor}"/>`:"";
  chartSvg.innerHTML=`<rect width="1000" height="600" rx="${style.borderRadius||0}" fill="${hexAlpha(style.background,style.backgroundOpacity||0)}"/>${grid}${axes}${ticks}${title}${legend}${fill}${traces}<line x1="${cursor}" y1="135" x2="${cursor}" y2="500" stroke="${style.cursorColor}" opacity=".8" stroke-width="2" stroke-dasharray="8 7"/>${livePoint}`;
}

document.querySelector("#playButton").addEventListener("click",()=>video.paused?video.play():video.pause());
document.querySelector("#timelineRange").addEventListener("input",event=>{if(video.duration)video.currentTime=Number(event.target.value)/1000*video.duration});
document.querySelector("#jumpIgnition").addEventListener("click",()=>video.currentTime=clamp(Number(form.elements.ignition_video_s.value)||0,0,video.duration||0));
function updateIgnitionMarker(){const d=video.duration||1,t=Number(form.elements.ignition_video_s.value)||0;document.querySelector("#ignitionMarker").style.left=`${clamp(t/d*100,0,100)}%`}
function formatTime(seconds){if(!Number.isFinite(seconds))return"00:00.00";const m=Math.floor(seconds/60),s=seconds-m*60;return`${String(m).padStart(2,"0")}:${s.toFixed(2).padStart(5,"0")}`}

document.querySelector("#toggleVisible").addEventListener("click",()=>mutateSelected(el=>el.visible=el.visible===false));
document.querySelector("#toggleLock").addEventListener("click",()=>mutateSelected(el=>el.locked=!el.locked));
document.querySelector("#moveUp").addEventListener("click",()=>mutateSelected(el=>el.z=(el.z||0)+1));
document.querySelector("#moveDown").addEventListener("click",()=>mutateSelected(el=>el.z=(el.z||0)-1));
document.querySelector("#resetElement").addEventListener("click",()=> {
  const original=initialScene.elements.find(item=>item.id===selectedId); if(!original)return;
  snapshot(); const index=scene.elements.findIndex(item=>item.id===selectedId); scene.elements[index]=clone(original); renderScene();selectElement(selectedId);saveDraft();
});
function mutateSelected(callback){if(!selected())return;snapshot();callback(selected());renderScene();selectElement(selectedId);saveDraft()}
document.querySelector("#undoButton").addEventListener("click",()=>{if(!undoStack.length)return;redoStack.push(JSON.stringify(scene));restore(undoStack.pop());saveDraft()});
document.querySelector("#redoButton").addEventListener("click",()=>{if(!redoStack.length)return;undoStack.push(JSON.stringify(scene));restore(redoStack.pop());saveDraft()});
document.querySelector("#saveTemplate").addEventListener("click",()=>{saveDraft();notify("تم حفظ التصميم في هذا المتصفح.")});
document.querySelector("#exportTemplate").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify(scene,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob),link=document.createElement("a");
  link.href=url;link.download=`rocket-overlay-template-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(link);link.click();link.remove();URL.revokeObjectURL(url);
  notify("تم تصدير القالب بنجاح.");
});
document.querySelector("#importTemplate").addEventListener("change",async event=>{
  const file=event.target.files[0];if(!file)return;
  try{
    const imported=JSON.parse(await file.text());
    if(!imported||!Array.isArray(imported.elements)||!imported.elements.length)throw new Error("ملف القالب غير صالح.");
    snapshot();scene=imported;renderScene();selectElement(null);saveDraft();notify("تم استيراد القالب بنجاح.");
  }catch(error){notify(error.message||"تعذر استيراد القالب.");}
  event.target.value="";
});
document.querySelector("#resetScene").addEventListener("click",()=>{snapshot();scene=clone(initialScene);renderScene();selectElement(null);saveDraft()});
function saveDraft(){localStorage.setItem("rocket-overlay-scene",JSON.stringify(scene))}

const templates={
  engineering:{chart:{x:.04,y:.14,width:.51,height:.60,backgroundOpacity:.90,chartType:"line"},pressure:{x:.04,y:.78,width:.20,height:.10},thrust:{x:.25,y:.78,width:.20,height:.10}},
  overlay:{chart:{x:.675,y:.08,width:.305,height:.69,backgroundOpacity:.72},pressure:{x:.69,y:.8,width:.275,height:.09},thrust:{x:.69,y:.9,width:.275,height:.075}},
  side:{chart:{x:.70,y:.08,width:.29,height:.68,backgroundOpacity:1},pressure:{x:.72,y:.79,width:.25,height:.08},thrust:{x:.72,y:.89,width:.25,height:.07}},
  clean:{chart:{x:.055,y:.60,width:.50,height:.32,backgroundOpacity:.45},pressure:{x:.58,y:.78,width:.20,height:.10},thrust:{x:.79,y:.78,width:.18,height:.10}}
};
document.querySelectorAll("[data-template]").forEach(button=>button.addEventListener("click",()=>{
  snapshot();const preset=templates[button.dataset.template];
  Object.entries(preset).forEach(([id,values])=>Object.assign(scene.elements.find(item=>item.id===id),values));
  renderScene();saveDraft();
}));
document.querySelector("#stageZoom").addEventListener("input",event=>{const value=Number(event.target.value);document.querySelector("#zoomValue").textContent=`${value}%`;stage.style.width=`${value}%`});
document.querySelector("#resolution").addEventListener("change",event=>{const[w,h]=event.target.value.split("x").map(Number);stage.style.aspectRatio=`${w}/${h}`});

async function startExport(event) {
  event?.preventDefault();
  if(!videoInput.files[0]||!dataInput.files[0]){notify("اختر الفيديو وملف القياسات أولًا.");return}
  if(!scene){notify("انتظر اكتمال تحميل المحرر ثم حاول مرة أخرى.");return}
  const body=new FormData(form);
  body.set("scene_config",JSON.stringify(scene));
  for(const [name,id] of [["keep_audio","keepAudio"],["reveal_chart","revealChart"],["enhance_video","enhanceVideo"],["denoise_video","denoiseVideo"],["stabilize_video","stabilizeVideo"],["thumbnail","thumbnail"]])
    body.set(name,document.querySelector(`#${id}`).checked?"true":"false");
  const button=document.querySelector("#renderButton");button.disabled=true;
  button.textContent="جارٍ رفع الملفات…";
  document.querySelector("#progressBox").classList.remove("hidden");updateProgress(0,"جارٍ رفع الملفات — 0%");
  try{
    await uploadFilesInChunks(body);
    const payload=await uploadJob(body);
    updateProgress(0,"اكتمل الرفع — جارٍ بدء معالجة الفيديو");
    button.textContent="جارٍ معالجة الفيديو…";
    pollJob(payload.id);
  }
  catch(error){resetRenderButton();updateProgress(0,`خطأ: ${error.message}`);notify(error.message)}
}
form.addEventListener("submit", startExport);
document.querySelector("#renderButton").addEventListener("click", startExport);
async function uploadFilesInChunks(body) {
  const fields = [
    ["video",videoInput],["video_2",videoInput2],["video_3",videoInput3],
    ["data",dataInput],["logo",logoInput]
  ].filter(([,input])=>input.files[0]);
  const total = fields.reduce((sum,[,input])=>sum+input.files[0].size,0);
  let uploaded = 0;
  const chunkSize = 2 * 1024 * 1024;
  for (const [field,input] of fields) {
    const file = input.files[0];
    const initResponse = await fetch("/api/uploads/init", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({field,filename:file.name,size:file.size})
    });
    const initPayload = await initResponse.json();
    if (!initResponse.ok) throw new Error(initPayload.error||"تعذر بدء رفع الملف.");
    if (initPayload.reused) {
      uploaded += file.size;
      updateProgress(Math.round(uploaded/total*100),`تم استعادة ${file.name} — دون إعادة رفع`);
    }
    for (let offset=0; !initPayload.reused && offset<file.size; offset+=chunkSize) {
      const chunk=file.slice(offset,Math.min(file.size,offset+chunkSize));
      const response=await fetch(`/api/uploads/${initPayload.upload_id}`, {
        method:"POST", body:chunk,
        headers:{"Content-Type":"application/octet-stream"}
      });
      const payload=await response.json();
      if (!response.ok) throw new Error(payload.error||`تعذر رفع ${file.name}`);
      uploaded += chunk.size;
      const percent=Math.round(uploaded/total*100);
      updateProgress(percent,`جارٍ رفع الملفات — ${formatBytes(uploaded)} من ${formatBytes(total)}`);
    }
    body.delete(field);
    body.set(`${field}_token`,initPayload.upload_id);
  }
}
function uploadJob(body){
  return new Promise((resolve,reject)=>{
    const request=new XMLHttpRequest();
    request.open("POST","/api/jobs");
    request.addEventListener("load",()=>{
      let payload={};
      try{payload=JSON.parse(request.responseText||"{}")}catch{}
      if(request.status>=200&&request.status<300)resolve(payload);
      else reject(new Error(payload.error||`تعذر رفع الملفات (${request.status})`));
    });
    request.addEventListener("error",()=>reject(new Error("انقطع الاتصال أثناء رفع الملفات.")));
    request.addEventListener("abort",()=>reject(new Error("تم إلغاء رفع الملفات.")));
    request.send(body);
  });
}
function formatBytes(bytes){
  if(bytes<1024*1024)return`${(bytes/1024).toFixed(1)} KB`;
  return`${(bytes/1024/1024).toFixed(1)} MB`;
}
function updateProgress(value,message){document.querySelector("#progressValue").textContent=`${value}%`;document.querySelector("#progressBar").style.width=`${value}%`;document.querySelector("#progressMessage").textContent=message;document.querySelector("#systemStatus").textContent=value===100?"اكتمل":"جارٍ المعالجة"}
function resetRenderButton(){const button=document.querySelector("#renderButton");button.disabled=false;button.textContent="▶ تصدير الفيديو النهائي"}
function pollJob(id){clearTimeout(pollTimer);fetch(`/api/jobs/${id}`).then(r=>r.json()).then(job=>{updateProgress(job.progress||0,job.message);if(job.status==="complete"){document.querySelector("#downloadLink").href=job.result_url;const thumb=document.querySelector("#thumbnailLink");if(job.thumbnail_url){thumb.href=job.thumbnail_url;thumb.classList.remove("hidden")}document.querySelector("#resultActions").classList.remove("hidden");resetRenderButton();return}if(job.status==="error"){resetRenderButton();updateProgress(job.progress||0,`خطأ: ${job.message}`);notify(job.message);return}pollTimer=setTimeout(()=>pollJob(id),1000)}).catch(error=>{resetRenderButton();updateProgress(0,`خطأ: ${error.message}`);notify(error.message)})}

initialize();
